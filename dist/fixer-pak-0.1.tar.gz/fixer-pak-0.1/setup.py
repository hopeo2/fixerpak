from setuptools import setup

setup(name='fixer-pak',
      version='0.1',
      description='Fixer service',
      url='#',
      author='omid',
      author_email='omidobeidzadeh@gmail.com',
      license='MIT',
      packages=['fixer'],
      zip_safe=False)
